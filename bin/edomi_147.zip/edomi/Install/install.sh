# ------------------------------------------------------------------------------------------------------------------------------------------------
# 1. zunächst manuell den USB-Stick mounten:
# 	mkdir /usb
# 	mount -t vfat /dev/sdb1 /usb (Devicename sdb1 ggf. anpassen)
#
# 2. in das Mount-Verzeichnis wechseln:
# 	cd /usb/edomi/install
#
# 3. Installation starten:
# 	sh install.sh
#
# 4. nach Abschluss der Installation ggf. den USB-Stick auswerfen:
#	cd /
# 	umount /usb
# ------------------------------------------------------------------------------------------------------------------------------------------------
# Konfiguration:
# ------------------------------------------------------------------------------------------------------------------------------------------------

# IP-Adresse des EDOMI-Rechners
SERVERIP="192.168.0.10"

# Gateway-Adresse (i.d.R. der DSL-Router)
GATEWAYIP="192.168.0.1"

# Subnet-Maske
NETMASK="255.255.255.0"

# ------------------------------------------------------------------------------------------------------------------------------------------------

# EDOMI-Hauptpfad (NICHT ÄNDERN!)
MAIN_PATH="/usr/local/edomi"






install_timezone () {
	# Zeitzone zur Sicherheit auf GMT einstellen
	echo -e "\033[32m"
	echo "Zeitzone: GMT0"
	echo -e "\033[39m"
	rm -f /etc/localtime
	ln -s /usr/share/zoneinfo/GMT0 /etc/localtime
	echo "---fertig---"
}

install_rpm () {
	echo -e "\033[32m"
	echo "Packete installieren"
	echo -e "\033[39m"
	rpm -Uvh rpm/install/*.rpm
	# rpm -Uvh rpm/_all/*.rpm
	# rpm -Uvh rpm/_gd/*.rpm
	echo "---fertig---"
}

install_config () {
	echo -e "\033[32m"
	echo "Grundkonfiguration"
	echo -e "\033[39m"
	
	# Firewall
	cp config/config /etc/selinux/
	
	# Nameserver (DNS)
	# Update: Wird jetzt im networkscript erledigt
	# cp config/resolv.conf /etc/
	# sed -i -e "s#===INSTALL-GATEWAYIP===#$GATEWAYIP#g" /etc/resolv.conf
	
	# Apache
	cp config/welcome.conf /etc/httpd/conf.d/
	cp config/httpd.conf /etc/httpd/conf/
	sed -i -e "s#===INSTALL-HTTP-ROOT===#$MAIN_PATH/www#g" /etc/httpd/conf/httpd.conf
	sed -i -e "s#===INSTALL-SERVERIP===#$SERVERIP#g" /etc/httpd/conf/httpd.conf
	
	# PHP
	cp config/php.conf /etc/httpd/conf.d/
	cp config/php.ini /etc/
	
	# mySQL
	cp config/my.cnf /etc/
	
	# FTP
	cp config/vsftpd.conf /etc/vsftpd/
	rm -f /etc/vsftpd/ftpusers
	rm -f /etc/vsftpd/user_list
	
	echo "---fertig---"
}

install_services () {
	echo -e "\033[32m"
	echo "Dienste konfigurieren" 
	echo -e "\033[39m"
	
	chkconfig --add httpd
	chkconfig --add mysqld
	chkconfig --add vsftpd
	chkconfig --add ntpd
	
	chkconfig --level 235 httpd on
	chkconfig --level 235 mysqld on
	chkconfig --level 235 vsftpd on
	chkconfig --level 235 ntpd on
	
	chkconfig --level 123456 crond off
	chkconfig crond --del
	chkconfig --level 123456 postfix off
	chkconfig postfix --del
	chkconfig --level 123456 blk-availability off
	chkconfig blk-availability --del
	chkconfig --level 123456 lvm2-monitor off
	chkconfig lvm2-monitor --del
	chkconfig --level 123456 mdmonitor off
	chkconfig mdmonitor --del
	chkconfig --level 123456 multipathd off
	chkconfig multipathd --del
	chkconfig --level 123456 netconsole off
	chkconfig netconsole --del
	chkconfig --level 123456 rdisc off
	chkconfig rdisc --del
	chkconfig --level 123456 restorecond off
	chkconfig restorecond --del
	chkconfig --level 123456 saslauthd off
	chkconfig saslauthd --del
	chkconfig --level 123456 auditd off
	chkconfig auditd --del
	
	# Firewall IP4 ausschalten
	service iptables save
	service iptables stop
	chkconfig --level 123456 iptables off
	chkconfig iptables --del
	
	# Firewall IP6 ausschalten
	service ip6tables save
	service ip6tables stop
	chkconfig --level 123456 ip6tables off
	chkconfig ip6tables --del
	
	# System-Logging ausschalten
	service rsyslog stop
	chkconfig rsyslog off
	chkconfig rsyslog --del
	
	service mysqld start
	service vsftpd start
	service ntpd start
	
	echo "---fertig---"
}


install_mysql () {
	echo -e "\033[32m"
	echo "mySQL-Konfiguration"
	echo -e "\033[39m"
	
	/usr/bin/mysqladmin -u root password ""
	mysql -e "DROP DATABASE test;"
	mysql -e "DELETE FROM mysql.db WHERE Db='test' OR Db='test\\_%'"
	mysql -e "FLUSH PRIVILEGES;"
	
	# Remote-Access aktivieren (z.B. vom iMac aus)
	mysql -e "GRANT ALL ON *.* TO mysql@'%';"
	
	echo "---fertig---"
}


install_network () {
	echo -e "\033[32m"
	echo "Netzwerk-Konfiguration"
	echo -e "\033[39m"
	
	sed -i "s/ONBOOT=no/ONBOOT=yes/g" /etc/sysconfig/network-scripts/ifcfg-eth0
	sed -i "s/BOOTPROTO=dhcp/BOOTPROTO=static/g" /etc/sysconfig/network-scripts/ifcfg-eth0
	echo "DHCPCLASS=" >> /etc/sysconfig/network-scripts/ifcfg-eth0
	echo "IPADDR=$SERVERIP" >> /etc/sysconfig/network-scripts/ifcfg-eth0
	echo "NETMASK=$NETMASK" >> /etc/sysconfig/network-scripts/ifcfg-eth0
	echo "GATEWAY=$GATEWAYIP" >> /etc/sysconfig/network-scripts/ifcfg-eth0
	# echo "PEERDNS=no" >> /etc/sysconfig/network-scripts/ifcfg-eth0
	
	# anstelle von /etc/resolv.conf (s.o.)
	echo "PEERDNS=yes" >> /etc/sysconfig/network-scripts/ifcfg-eth0
	echo "DNS1=$GATEWAYIP" >> /etc/sysconfig/network-scripts/ifcfg-eth0
	
	echo "---fertig---"
}


delete_edomi () {
	echo -e "\033[32m"
	echo "EDOMI-Installation entfernen"
	echo -e "\033[39m"
	
	service mysqld stop
	sleep 1
	
	rm -rf $MAIN_PATH
	rm -rf /var/lib/mysql/edomi*

	echo "---fertig---"
}


install_edomi () {
	service mysqld stop
	sleep 1

	if [ -f "EDOMI/EDOMI-Backup.edomibackup" ]
	then
		echo -e "\033[32m"
		echo "EDOMI installieren (Devel)"
		echo -e "\033[39m"
		tar -xf EDOMI/EDOMI-Backup.edomibackup -C /
		chmod 777 -R $MAIN_PATH		
	else
		echo -e "\033[32m"
		echo "EDOMI installieren (Public)"
		echo -e "\033[39m"
		mkdir -p $MAIN_PATH
		tar -xf EDOMI/EDOMI-Public.edomiinstall -C $MAIN_PATH --strip-components=3
		chmod 777 -R $MAIN_PATH
	fi

	# edomi.ini anpassen
	sed -i -e "s#global_serverIP.*#global_serverIP='$SERVERIP'#" $MAIN_PATH/edomi.ini
	echo "---fertig---"
}


install_boot () {
	echo -e "\033[32m"
	echo "Autostart einrichten"
	echo -e "\033[39m"
	
	# grub.conf: quiet-Modus deaktivieren (damit die Ausgaben von EDOMI per Default sichtbar sind)
	sed -i -e 's/quiet//g' /boot/grub/grub.conf
	sed -i -e 's/rhgb//g' /boot/grub/grub.conf
	
	# boot.log löschen
	chmod 777 /var/log/boot.log
	rm -f /var/log/boot.log
	
	# Autostart: EDOMI
	echo "sh $MAIN_PATH/main/start.sh" >> /etc/rc.d/rc.local
	echo "---fertig---"
}


install_extensions () {
	echo -e "\033[32m"
	echo "PHP-Extensions installieren"
	echo -e "\033[39m"
	
	cp php/bcompiler.so /usr/lib64/php/modules/bcompiler.so
	cp php/bcompiler.ini /etc/php.d/bcompiler.ini
	
	echo "---fertig---"
}


show_splash () {
	echo -e "\033[32m"
	echo "--------------------------------------------------------------------------------"
	echo "                                                                                "
	echo "        OOOOOOOOOOO  OOOOOOOO        OOOOOOOOO        OOOOOOOOOOOOOO  O         "
	echo "        O            O       OO    OO         OO    OO     O       O  O         "
	echo "        O            O         O  O             O  O       O       O  O         "
	echo "        OOOOOOOO     O         O  O             O  O       O       O  O         "
	echo "        O            O         O  O             O  O       O       O  O         "
	echo "        O            O       OO    OO         OO   O       O       O  O         "
	echo "        OOOOOOOOOOO  OOOOOOOO        OOOOOOOOO     O       O       O  O         "
	echo "                                                                                "
	echo "        EDOMI-Installation abgeschlossen      (c) Dr. Christian Gärtner         "
	echo "                                                                                "
	echo "--------------------------------------------------------------------------------"
	echo "Beim nächsten Reboot wird EDOMI automatisch gestartet! Neustart mit: reboot"
	echo -e "\033[39m"
}



# Installationsscript

osversion="$(cat /etc/issue)"
while : ; do

	clear
	echo "================================================================================"
	echo "                                                                                "
	echo "                       EDOMI - (c) Dr. Christian Gärtner                        "
	echo "                                                                                "
	echo "================================================================================"
	echo ""
	if  [[ "$osversion" != "CentOS release 6.5"* ]]; then
		echo -e "\033[41m\033[30mACHTUNG: Es wurde ein nicht unterstütztes Betriebsystem erkannt!                \033[49m\033[39m"
		echo -e "\033[41m\033[30mEDOMI sollte ausschließlich unter CentOS 6.5 64bit installiert werden!          \033[49m\033[39m"
	fi
	echo "Zielpfad   : $MAIN_PATH"
	echo ""
	echo "IP-Adresse : $SERVERIP"
	echo "Gateway-IP : $GATEWAYIP"
	echo "Netmask    : $NETMASK"
	echo ""
	echo "--------------------------------------------------------------------------------"
	echo " 1 (ENTER) = IP-Adresse anpassen"
	echo " 2 (ENTER) = Gateway-IP (DNS) anpassen"
	echo " 3 (ENTER) = Netmask anpassen"
	echo ""
	echo " s (ENTER) = EDOMI installieren (Erstinstallation)"
	echo ""
	echo " o (ENTER) = EDOMI erneut installieren (vorhandene Installation wird gelöscht!)"
	echo " q (ENTER) = Beenden"
	echo "--------------------------------------------------------------------------------"

	read answer 

	if [ "$answer" == "1" ]; then 
		read -p "IP-Adresse: " SERVERIP
	fi 

	if [ "$answer" == "2" ]; then 
		read -p "Gateway-IP: " GATEWAYIP
	fi

	if [ "$answer" == "3" ]; then 
		read -p "Netmask: " NETMASK
	fi

	if [ "$answer" == "s" ]; then 
		clear
		echo -e "\033[32m"
		echo "EDOMI-Installation..."
		echo -e "\033[39m"
		sleep 3
		install_rpm
		install_config
		install_services
		install_mysql
		install_network		
		install_edomi
		install_boot
		install_extensions
		show_splash
		exit
	fi 

	if [ "$answer" == "o" ]; then 
		clear
		echo -e "\033[32m"
		echo "EDOMI erneut installieren..."
		echo -e "\033[39m"
		sleep 3
		delete_edomi
		install_edomi
		show_splash
		exit
	fi 

	if [ "$answer" == "q" ]; then 
		exit
	fi 

done
















